## v1.9.3 (2026-11-16)
- Verified marketplace release with security inspection passed.
- Performance tuning and responsive UI polish.
