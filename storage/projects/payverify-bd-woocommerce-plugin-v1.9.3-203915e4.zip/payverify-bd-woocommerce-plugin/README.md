# PayVerify BD — Manual bKash, Nagad & Rocket Checkout for WooCommerce (v1.9.3)

Author Studio: @padmasoft
Compatibility: WordPress 6.4+, WooCommerce 8.5–9.x (HPOS)
License: regular

## Summary
Secure WooCommerce manual mobile banking gateway with unique TrxID validation, receipt proof upload, SMS hooks, and fraud audit logs.

## Included Features
- Dedicated bKash, Nagad & Rocket tabs with copyable account number
- Unique Transaction ID constraint & sender number format validation
- Optional payment screenshot proof upload with MIME inspection
- Full WooCommerce High-Performance Order Storage (HPOS) compatibility
- Printable BDT invoice badge showing verified TrxID & method
- Exportable CSV reconciliation sheet for monthly accounting

## Quick Start
1. Extract this archive into your workspace.
2. Follow docs/SETUP.md to configure environment variables.
3. Reach out via Buyer Dashboard > Support Tickets for verified support.
