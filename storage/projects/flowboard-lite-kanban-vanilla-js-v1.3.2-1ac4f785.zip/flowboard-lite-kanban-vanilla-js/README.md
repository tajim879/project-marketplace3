# FlowBoard Lite — Zero-Dependency Drag & Drop Kanban Vanilla JS App (v1.3.2)

Author Studio: @padmasoft
Compatibility: ES2022 Browsers, HTML5, CSS3
License: mit

## Summary
Lightweight interactive Kanban task board written in pure ES2022 JavaScript with priority tags, search filtering, and JSON import/export.

## Included Features
- Smooth column & card drag-and-drop with touch pointer support
- Priority labels, due dates, checklist progress & instant filter
- LocalStorage persistence + clean REST API sync hook
- One-click JSON workspace export & restore
- Clean commented ES module source code

## Quick Start
1. Extract this archive into your workspace.
2. Follow docs/SETUP.md to configure environment variables.
3. Reach out via Buyer Dashboard > Support Tickets for verified support.
