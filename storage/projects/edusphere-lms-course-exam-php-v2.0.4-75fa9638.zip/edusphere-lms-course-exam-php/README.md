# EduSphere LMS — Course, Exam & Certificate Management Native PHP Platform (v2.0.4)

Author Studio: @dhakalabs
Compatibility: PHP 8.2+, MySQL 8+, Shared Hosting Ready
License: regular

## Summary
Clean coaching & online academy platform with cohort scheduling, timed MCQ exams, bKash tuition verification, and verifiable PDF certificates.

## Included Features
- Student, Instructor & Administrator dedicated dashboards
- Timed MCQ & written assignment engine with instant analytics
- Manual bKash, Nagad & Rocket enrollment payment verification
- Public certificate verification URL with unique serial code
- Protected lesson attachment downloads for enrolled learners only
- Responsive mobile-first exam interface tested down to 360px

## Quick Start
1. Extract this archive into your workspace.
2. Follow docs/SETUP.md to configure environment variables.
3. Reach out via Buyer Dashboard > Support Tickets for verified support.
