# SwiftDrop — Multi-Vendor Courier & Parcel Tracking Android App + PHP API (v2.5.0)

Author Studio: @pixelforge_bd
Compatibility: Android SDK 24–35, PHP 8.2+, MySQL 8+
License: regular

## Summary
End-to-end delivery management Android Studio solution featuring Merchant App, Rider App, live barcode scan, and PDO PHP REST backend.

## Included Features
- Merchant booking app + Rider pickup/delivery scanner app included
- Real-time status timeline from Booked to Hub Transit to Delivered
- COD collection ledger & automated merchant payout sheets
- Camera QR/Barcode label scanner with offline queue
- Complete Native PHP 8.2 REST API & web dispatch dashboard
- Step-by-step deployment & APK/AAB signing documentation

## Quick Start
1. Extract this archive into your workspace.
2. Follow docs/SETUP.md to configure environment variables.
3. Reach out via Buyer Dashboard > Support Tickets for verified support.
