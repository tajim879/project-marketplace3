## v2.7.0 (2026-11-16)
- Verified marketplace release with security inspection passed.
- Performance tuning and responsive UI polish.
