# BazaarGrid — Ultra-Fast WooCommerce & Digital Store WordPress Theme (v2.7.0)

Author Studio: @karnafuli_ui
Compatibility: WordPress 6.5+, WooCommerce 9+, PHP 8.1+
License: regular

## Summary
99 Lighthouse-scoring Gutenberg & WooCommerce theme with AJAX filters, instant drawer cart, schema SEO, and zero jQuery bloat.

## Included Features
- Zero jQuery storefront scripts — pure Vanilla JS & Fetch API
- Slide-out AJAX mini-cart with free-shipping progress bar
- Instant facet filtering by attribute, price, rating & stock
- Built-in Product, Breadcrumb & FAQ JSON-LD structured data
- Child theme starter & one-click demo XML importer included
- Native Hind Siliguri & Inter typography presets

## Quick Start
1. Extract this archive into your workspace.
2. Follow docs/SETUP.md to configure environment variables.
3. Reach out via Buyer Dashboard > Support Tickets for verified support.
