# RetailPulse Pro — Multi-Branch POS, Inventory & Accounting PHP System (v3.4.0)

Author Studio: @dhakalabs
Compatibility: PHP 8.2+, MySQL 8+, Apache/Nginx
License: regular

## Summary
Complete Native PHP 8.2+ & MySQL barcode POS, stock ledger, supplier billing, VAT invoicing, and role-based branch analytics.

## Included Features
- Fast keyboard & barcode scanner POS terminal with hold-bill support
- Multi-branch stock transfers, low-stock alerts & batch tracking
- Thermal 58mm/80mm & A4 BDT invoice printing
- Immutable purchase, sales return & expense financial ledger
- Granular cashier, branch manager & administrator RBAC permissions
- Guided shared-hosting installation wizard & automated DB backups

## Quick Start
1. Extract this archive into your workspace.
2. Follow docs/SETUP.md to configure environment variables.
3. Reach out via Buyer Dashboard > Support Tickets for verified support.
