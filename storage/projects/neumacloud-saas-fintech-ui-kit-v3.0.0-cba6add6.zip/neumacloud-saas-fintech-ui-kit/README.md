# NeumaCloud — Soft Neumorphic SaaS & Fintech Figma + CSS Design System (v3.0.0)

Author Studio: @karnafuli_ui
Compatibility: Figma (Variables + Auto Layout), CSS3, SVG
License: regular

## Summary
420+ auto-layout Figma components, 48 responsive desktop & mobile screens, and production CSS custom-property tokens.

## Included Features
- 420+ variant-driven Figma components with interactive states
- 48 complete SaaS, marketplace & fintech screen templates
- Responsive breakpoints for 360px, 768px, 1024px & 1440px
- 120 matching 24x24 stroke-consistent outline SVG icons
- Ready-to-paste CSS3 custom properties (`variables.css`)
- Typography hierarchy built on Inter & Manrope

## Quick Start
1. Extract this archive into your workspace.
2. Follow docs/SETUP.md to configure environment variables.
3. Reach out via Buyer Dashboard > Support Tickets for verified support.
