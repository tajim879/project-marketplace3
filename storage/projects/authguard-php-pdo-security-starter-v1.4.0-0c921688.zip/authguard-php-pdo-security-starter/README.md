# AuthGuard PHP — Secure PDO Session, CSRF & Rate-Limiter Starter Script (v1.4.0)

Author Studio: @dhakalabs
Compatibility: PHP 8.2+, MySQL 8+ / MariaDB 10.6+
License: free_personal

## Summary
Free production-hardened Native PHP 8.2+ authentication starter with Argon2/Bcrypt hashing, CSRF tokens, login lockout, and audit logs.

## Included Features
- Prepared PDO queries, session regeneration & HttpOnly cookies
- Configurable brute-force rate limiter with automatic cooldown
- Active device session viewer with one-click session revocation
- Ready-to-import InnoDB utf8mb4 SQL migration
- Clean soft-neumorphic Login, Register & Reset UI included

## Quick Start
1. Extract this archive into your workspace.
2. Follow docs/SETUP.md to configure environment variables.
3. Reach out via Buyer Dashboard > Support Tickets for verified support.
