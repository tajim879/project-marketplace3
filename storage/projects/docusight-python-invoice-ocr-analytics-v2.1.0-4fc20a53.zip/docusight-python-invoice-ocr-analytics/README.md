# DocuSight AI — Python Invoice OCR, Table Extractor & Analytics Suite (v2.1.0)

Author Studio: @padmasoft
Compatibility: Python 3.11+, Linux / Windows / macOS
License: regular

## Summary
Self-hosted Python web suite that parses PDF/scanned invoices into structured SQL/Excel tables with anomaly detection and spend charts.

## Included Features
- Batch PDF & scanned receipt ingestion with deskew preprocessing
- Line-item quantity, unit price & tax reconciliation validator
- Duplicate invoice number & unusual vendor spike detection
- Clean browser review queue & verified XLSX/CSV export
- Docker & standard virtualenv setup scripts included
- Unit test suite with 45 sample synthetic invoices

## Quick Start
1. Extract this archive into your workspace.
2. Follow docs/SETUP.md to configure environment variables.
3. Reach out via Buyer Dashboard > Support Tickets for verified support.
