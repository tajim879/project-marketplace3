# MediDesk Java — Clinic Patient Queue, Prescription & Billing Desktop Suite (v1.8.0)

Author Studio: @pixelforge_bd
Compatibility: Java 21 LTS, MySQL 8+, Windows / Linux / macOS
License: regular

## Summary
Cross-platform Java 21 desktop application for diagnostic centers and chambers with medicine database, Rx printing, and MySQL sync.

## Included Features
- Multi-workstation Reception & Doctor synchronized LAN workflow
- Searchable 18,000+ generic/brand medicine dosage autocomplete
- One-click A4 prescription & diagnostic cash memo printing
- Daily collection summary, due recovery & doctor commission report
- Role-based staff audit logs & scheduled encrypted SQL backups
- Maven project structure with clean build instructions

## Quick Start
1. Extract this archive into your workspace.
2. Follow docs/SETUP.md to configure environment variables.
3. Reach out via Buyer Dashboard > Support Tickets for verified support.
