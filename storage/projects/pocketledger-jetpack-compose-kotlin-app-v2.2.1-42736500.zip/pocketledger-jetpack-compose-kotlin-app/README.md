# PocketLedger — Jetpack Compose Personal Finance & Budget Kotlin App (v2.2.1)

Author Studio: @pixelforge_bd
Compatibility: Android Studio Ladybug, Kotlin 2.0, SDK 26–35
License: regular

## Summary
Offline-first native Kotlin & Jetpack Compose finance tracker with Room database, Material 3 UI, biometric lock, and CSV/PDF reports.

## Included Features
- 100% Jetpack Compose UI with dynamic light & dark colour tokens
- Multi-wallet tracking (Cash, Bank, bKash, Nagad, Cards)
- Recurring bills reminder engine via WorkManager
- Fingerprint / Face BiometricPrompt privacy lock
- One-tap PDF monthly statement & encrypted JSON backup
- Complete Gradle Kotlin DSL multi-module source code

## Quick Start
1. Extract this archive into your workspace.
2. Follow docs/SETUP.md to configure environment variables.
3. Reach out via Buyer Dashboard > Support Tickets for verified support.
